# Sprint 3 Deployment: Natural AI Communication

## Deployment Notes for Sprint 3

Deploying: Natural AI Communication.

### Release Checklist:
- [x] Documented and deployed: Develop Multi-Turn Voice Interaction
- [x] Documented and deployed: Integrate Local LLM for Privacy
- [x] Documented and deployed: Test Natural Language Processing
- [x] Documented and deployed: Refine Conversational Context

### References & Resources:
- [[1] Ollama documentation for running local LLMs on Raspberry Pi](https://dev.to/thegeoffstevens/building-a-completely-offline-voice-assistant-using-a-raspberry-pi-a-local-llm-and-websockets-1ibf)
- [[2] Vosk & faster-whisper open-source STT for local setups](https://github.com/maxolasersquad/max-headbox)
- [[3] Piper Text-to-Speech (TTS) engine for offline voice](https://dev.to/thegeoffstevens/building-a-completely-offline-voice-assistant-using-a-raspberry-pi-a-local-llm-and-websockets-1ibf)
