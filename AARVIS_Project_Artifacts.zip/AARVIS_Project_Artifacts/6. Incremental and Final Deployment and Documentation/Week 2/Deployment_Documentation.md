# Sprint 2 Deployment: Morning Briefings & News

## Deployment Notes for Sprint 2

Deploying: Morning Briefings & News.

### Release Checklist:
- [x] Documented and deployed: Integrate Calendar/Email/Weather APIs
- [x] Documented and deployed: Develop Personalized Briefing Logic
- [x] Documented and deployed: Integrate Business News Feeds
- [x] Documented and deployed: Test Auto Delivery on Face Recognition

### References & Resources:
- [[1] OpenWeatherMap API setup for smart mirror widgets](https://maker.pro/raspberry-pi/projects/how-to-build-a-raspberry-pi-smart-mirror)
- [[2] Google Calendar iCal integration guidelines](https://howtogeek.com/423166/how-to-build-a-smart-mirror-with-a-raspberry-pi/)
- [[3] MagicMirror² Newsfeed integration](https://github.com/MichMich/MagicMirror/tree/master/modules/default/newsfeed)
