# Sprint 5 Deployment: Voice-Controlled Scheduling

## Deployment Notes for Sprint 5

Deploying: Voice-Controlled Scheduling.

### Release Checklist:
- [x] Documented and deployed: Integrate Calendar API
- [x] Documented and deployed: Develop NLP for Scheduling Commands
- [x] Documented and deployed: Test Voice-Based Event Management
- [x] Documented and deployed: User Feedback on Scheduling Accuracy

### References & Resources:
- [[1] Google Assistant / AIY Voice Kit integration](https://hackster.io/the-wakh-s/smart-mirror-touchscreen-with-face-recognition-a3e3b5)
- [[2] Google Calendar API OAuth2 guide](https://developers.google.com/calendar/api/guides/auth)
- [[3] Automated scheduling workflows utilizing Microsoft Graph API](https://moldstud.com/articles/p-how-to-build-a-smart-mirror-using-raspberry-pi)
