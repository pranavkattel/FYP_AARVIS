# Sprint 1 Deployment: Facial Recognition Authentication

## Deployment Notes for Sprint 1

Deploying: Facial Recognition Authentication.

### Release Checklist:
- [x] Documented and deployed: Develop Multi-User Face Recognition
- [x] Documented and deployed: Integrate Face Auth with Camera
- [x] Documented and deployed: Test User Differentiation
- [x] Documented and deployed: Implement Privacy Controls

### References & Resources:
- [[1] MagicMirror² OpenCV Tutorials - Integration of Face Recognition](https://github.com/EbenKouao/Smart-Mirror-Touchscreen)
- [[2] SmartBuilds.io: Smart Mirror Touchscreen (with FaceID) Tutorial](https://smartbuilds.io/smart-mirror-touchscreen-raspberry-pi-4/)
- [[3] Github: Smart-Mirror-with-Real-Time-Face-Detection](https://github.com/ELDERGARLIC/Smart-Mirror-with-Real-Time-Face-Detectio-and-Recognition)
