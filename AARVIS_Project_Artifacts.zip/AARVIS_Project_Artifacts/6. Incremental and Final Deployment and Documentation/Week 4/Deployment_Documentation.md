# Sprint 4 Deployment: Hardware Setup

## Deployment Notes for Sprint 4

Deploying: Hardware Setup.

### Release Checklist:
- [x] Documented and deployed: Set up Raspberry Pi
- [x] Documented and deployed: Mount monitor and camera
- [x] Documented and deployed: Test basic connections
- [x] Documented and deployed: Ensure network connectivity

### References & Resources:
- [[1] Raspberry Pi 4/5 hardware specifications](https://raspberrypi.com/news/how-to-build-a-super-slim-smart-mirror/)
- [[2] Instructables: Building a wooden frame for a two-way mirror](https://instructables.com/id/How-to-Make-a-Smart-Mirror-1/)
- [[3] VESA mounting techniques](https://all3dp.com/2/raspberry-pi-smart-mirror-best-projects/)
