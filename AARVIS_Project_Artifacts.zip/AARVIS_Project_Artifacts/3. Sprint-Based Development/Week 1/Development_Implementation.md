# Sprint 1 Development: Facial Recognition Authentication

## Development Log for Sprint 1

Implementing: Facial Recognition Authentication.

### Implementation Tasks:
- **Develop Multi-User Face Recognition**: (In Progress / Completed)
- **Integrate Face Auth with Camera**: (In Progress / Completed)
- **Test User Differentiation**: (In Progress / Completed)
- **Implement Privacy Controls**: (In Progress / Completed)

### References & Resources:
- [[1] MagicMirror² OpenCV Tutorials - Integration of Face Recognition](https://github.com/EbenKouao/Smart-Mirror-Touchscreen)
- [[2] SmartBuilds.io: Smart Mirror Touchscreen (with FaceID) Tutorial](https://smartbuilds.io/smart-mirror-touchscreen-raspberry-pi-4/)
- [[3] Github: Smart-Mirror-with-Real-Time-Face-Detection](https://github.com/ELDERGARLIC/Smart-Mirror-with-Real-Time-Face-Detectio-and-Recognition)
