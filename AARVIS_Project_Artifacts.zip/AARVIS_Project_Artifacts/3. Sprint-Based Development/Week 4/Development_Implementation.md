# Sprint 4 Development: Hardware Setup

## Development Log for Sprint 4

Implementing: Hardware Setup.

### Implementation Tasks:
- **Set up Raspberry Pi**: (In Progress / Completed)
- **Mount monitor and camera**: (In Progress / Completed)
- **Test basic connections**: (In Progress / Completed)
- **Ensure network connectivity**: (In Progress / Completed)

### References & Resources:
- [[1] Raspberry Pi 4/5 hardware specifications](https://raspberrypi.com/news/how-to-build-a-super-slim-smart-mirror/)
- [[2] Instructables: Building a wooden frame for a two-way mirror](https://instructables.com/id/How-to-Make-a-Smart-Mirror-1/)
- [[3] VESA mounting techniques](https://all3dp.com/2/raspberry-pi-smart-mirror-best-projects/)
