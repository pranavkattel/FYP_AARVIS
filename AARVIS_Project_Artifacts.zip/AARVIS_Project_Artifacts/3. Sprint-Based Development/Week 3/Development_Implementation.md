# Sprint 3 Development: Natural AI Communication

## Development Log for Sprint 3

Implementing: Natural AI Communication.

### Implementation Tasks:
- **Develop Multi-Turn Voice Interaction**: (In Progress / Completed)
- **Integrate Local LLM for Privacy**: (In Progress / Completed)
- **Test Natural Language Processing**: (In Progress / Completed)
- **Refine Conversational Context**: (In Progress / Completed)

### References & Resources:
- [[1] Ollama documentation for running local LLMs on Raspberry Pi](https://dev.to/thegeoffstevens/building-a-completely-offline-voice-assistant-using-a-raspberry-pi-a-local-llm-and-websockets-1ibf)
- [[2] Vosk & faster-whisper open-source STT for local setups](https://github.com/maxolasersquad/max-headbox)
- [[3] Piper Text-to-Speech (TTS) engine for offline voice](https://dev.to/thegeoffstevens/building-a-completely-offline-voice-assistant-using-a-raspberry-pi-a-local-llm-and-websockets-1ibf)
