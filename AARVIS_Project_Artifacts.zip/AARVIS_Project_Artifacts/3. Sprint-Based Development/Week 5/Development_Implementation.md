# Sprint 5 Development: Voice-Controlled Scheduling

## Development Log for Sprint 5

Implementing: Voice-Controlled Scheduling.

### Implementation Tasks:
- **Integrate Calendar API**: (In Progress / Completed)
- **Develop NLP for Scheduling Commands**: (In Progress / Completed)
- **Test Voice-Based Event Management**: (In Progress / Completed)
- **User Feedback on Scheduling Accuracy**: (In Progress / Completed)

### References & Resources:
- [[1] Google Assistant / AIY Voice Kit integration](https://hackster.io/the-wakh-s/smart-mirror-touchscreen-with-face-recognition-a3e3b5)
- [[2] Google Calendar API OAuth2 guide](https://developers.google.com/calendar/api/guides/auth)
- [[3] Automated scheduling workflows utilizing Microsoft Graph API](https://moldstud.com/articles/p-how-to-build-a-smart-mirror-using-raspberry-pi)
