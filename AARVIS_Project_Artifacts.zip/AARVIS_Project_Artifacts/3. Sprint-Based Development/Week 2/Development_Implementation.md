# Sprint 2 Development: Morning Briefings & News

## Development Log for Sprint 2

Implementing: Morning Briefings & News.

### Implementation Tasks:
- **Integrate Calendar/Email/Weather APIs**: (In Progress / Completed)
- **Develop Personalized Briefing Logic**: (In Progress / Completed)
- **Integrate Business News Feeds**: (In Progress / Completed)
- **Test Auto Delivery on Face Recognition**: (In Progress / Completed)

### References & Resources:
- [[1] OpenWeatherMap API setup for smart mirror widgets](https://maker.pro/raspberry-pi/projects/how-to-build-a-raspberry-pi-smart-mirror)
- [[2] Google Calendar iCal integration guidelines](https://howtogeek.com/423166/how-to-build-a-smart-mirror-with-a-raspberry-pi/)
- [[3] MagicMirror² Newsfeed integration](https://github.com/MichMich/MagicMirror/tree/master/modules/default/newsfeed)
