# Sprint 2 Testing: Morning Briefings & News

## Testing Report for Sprint 2

Validating: Morning Briefings & News.

### Test Cases:
- [ ] Verify functionality for: Integrate Calendar/Email/Weather APIs
- [ ] Verify functionality for: Develop Personalized Briefing Logic
- [ ] Verify functionality for: Integrate Business News Feeds
- [ ] Verify functionality for: Test Auto Delivery on Face Recognition

### References & Resources:
- [[1] OpenWeatherMap API setup for smart mirror widgets](https://maker.pro/raspberry-pi/projects/how-to-build-a-raspberry-pi-smart-mirror)
- [[2] Google Calendar iCal integration guidelines](https://howtogeek.com/423166/how-to-build-a-smart-mirror-with-a-raspberry-pi/)
- [[3] MagicMirror² Newsfeed integration](https://github.com/MichMich/MagicMirror/tree/master/modules/default/newsfeed)
