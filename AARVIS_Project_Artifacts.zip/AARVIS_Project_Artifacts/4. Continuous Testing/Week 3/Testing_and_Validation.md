# Sprint 3 Testing: Natural AI Communication

## Testing Report for Sprint 3

Validating: Natural AI Communication.

### Test Cases:
- [ ] Verify functionality for: Develop Multi-Turn Voice Interaction
- [ ] Verify functionality for: Integrate Local LLM for Privacy
- [ ] Verify functionality for: Test Natural Language Processing
- [ ] Verify functionality for: Refine Conversational Context

### References & Resources:
- [[1] Ollama documentation for running local LLMs on Raspberry Pi](https://dev.to/thegeoffstevens/building-a-completely-offline-voice-assistant-using-a-raspberry-pi-a-local-llm-and-websockets-1ibf)
- [[2] Vosk & faster-whisper open-source STT for local setups](https://github.com/maxolasersquad/max-headbox)
- [[3] Piper Text-to-Speech (TTS) engine for offline voice](https://dev.to/thegeoffstevens/building-a-completely-offline-voice-assistant-using-a-raspberry-pi-a-local-llm-and-websockets-1ibf)
