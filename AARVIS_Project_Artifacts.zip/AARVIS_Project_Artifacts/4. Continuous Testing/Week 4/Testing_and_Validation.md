# Sprint 4 Testing: Hardware Setup

## Testing Report for Sprint 4

Validating: Hardware Setup.

### Test Cases:
- [ ] Verify functionality for: Set up Raspberry Pi
- [ ] Verify functionality for: Mount monitor and camera
- [ ] Verify functionality for: Test basic connections
- [ ] Verify functionality for: Ensure network connectivity

### References & Resources:
- [[1] Raspberry Pi 4/5 hardware specifications](https://raspberrypi.com/news/how-to-build-a-super-slim-smart-mirror/)
- [[2] Instructables: Building a wooden frame for a two-way mirror](https://instructables.com/id/How-to-Make-a-Smart-Mirror-1/)
- [[3] VESA mounting techniques](https://all3dp.com/2/raspberry-pi-smart-mirror-best-projects/)
