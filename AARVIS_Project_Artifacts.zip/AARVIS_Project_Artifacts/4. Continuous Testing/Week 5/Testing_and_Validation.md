# Sprint 5 Testing: Voice-Controlled Scheduling

## Testing Report for Sprint 5

Validating: Voice-Controlled Scheduling.

### Test Cases:
- [ ] Verify functionality for: Integrate Calendar API
- [ ] Verify functionality for: Develop NLP for Scheduling Commands
- [ ] Verify functionality for: Test Voice-Based Event Management
- [ ] Verify functionality for: User Feedback on Scheduling Accuracy

### References & Resources:
- [[1] Google Assistant / AIY Voice Kit integration](https://hackster.io/the-wakh-s/smart-mirror-touchscreen-with-face-recognition-a3e3b5)
- [[2] Google Calendar API OAuth2 guide](https://developers.google.com/calendar/api/guides/auth)
- [[3] Automated scheduling workflows utilizing Microsoft Graph API](https://moldstud.com/articles/p-how-to-build-a-smart-mirror-using-raspberry-pi)
