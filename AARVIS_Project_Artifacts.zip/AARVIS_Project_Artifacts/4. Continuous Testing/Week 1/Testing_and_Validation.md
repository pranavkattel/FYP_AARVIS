# Sprint 1 Testing: Facial Recognition Authentication

## Testing Report for Sprint 1

Validating: Facial Recognition Authentication.

### Test Cases:
- [ ] Verify functionality for: Develop Multi-User Face Recognition
- [ ] Verify functionality for: Integrate Face Auth with Camera
- [ ] Verify functionality for: Test User Differentiation
- [ ] Verify functionality for: Implement Privacy Controls

### References & Resources:
- [[1] MagicMirror² OpenCV Tutorials - Integration of Face Recognition](https://github.com/EbenKouao/Smart-Mirror-Touchscreen)
- [[2] SmartBuilds.io: Smart Mirror Touchscreen (with FaceID) Tutorial](https://smartbuilds.io/smart-mirror-touchscreen-raspberry-pi-4/)
- [[3] Github: Smart-Mirror-with-Real-Time-Face-Detection](https://github.com/ELDERGARLIC/Smart-Mirror-with-Real-Time-Face-Detectio-and-Recognition)
