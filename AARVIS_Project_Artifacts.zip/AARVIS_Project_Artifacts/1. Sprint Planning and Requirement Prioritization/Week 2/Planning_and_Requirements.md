# Sprint 2 Planning: Morning Briefings & News

## Goals for Sprint 2

- Define requirements for Morning Briefings & News.
- Brainstorming factors based on smart mirror requirements.

### Tasks:
- [ ] Integrate Calendar/Email/Weather APIs
- [ ] Develop Personalized Briefing Logic
- [ ] Integrate Business News Feeds
- [ ] Test Auto Delivery on Face Recognition

### References & Resources:
- [[1] OpenWeatherMap API setup for smart mirror widgets](https://maker.pro/raspberry-pi/projects/how-to-build-a-raspberry-pi-smart-mirror)
- [[2] Google Calendar iCal integration guidelines](https://howtogeek.com/423166/how-to-build-a-smart-mirror-with-a-raspberry-pi/)
- [[3] MagicMirror² Newsfeed integration](https://github.com/MichMich/MagicMirror/tree/master/modules/default/newsfeed)
