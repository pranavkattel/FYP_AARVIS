# Sprint 4 Planning: Hardware Setup

## Goals for Sprint 4

- Define requirements for Hardware Setup.
- Brainstorming factors based on smart mirror requirements.

### Tasks:
- [ ] Set up Raspberry Pi
- [ ] Mount monitor and camera
- [ ] Test basic connections
- [ ] Ensure network connectivity

### References & Resources:
- [[1] Raspberry Pi 4/5 hardware specifications](https://raspberrypi.com/news/how-to-build-a-super-slim-smart-mirror/)
- [[2] Instructables: Building a wooden frame for a two-way mirror](https://instructables.com/id/How-to-Make-a-Smart-Mirror-1/)
- [[3] VESA mounting techniques](https://all3dp.com/2/raspberry-pi-smart-mirror-best-projects/)
