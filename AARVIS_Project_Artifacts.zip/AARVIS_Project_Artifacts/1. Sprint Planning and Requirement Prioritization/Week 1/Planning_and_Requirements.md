# Sprint 1 Planning: Facial Recognition Authentication

## Goals for Sprint 1

- Define requirements for Facial Recognition Authentication.
- Brainstorming factors based on smart mirror requirements.

### Tasks:
- [ ] Develop Multi-User Face Recognition
- [ ] Integrate Face Auth with Camera
- [ ] Test User Differentiation
- [ ] Implement Privacy Controls

### References & Resources:
- [[1] MagicMirror² OpenCV Tutorials - Integration of Face Recognition](https://github.com/EbenKouao/Smart-Mirror-Touchscreen)
- [[2] SmartBuilds.io: Smart Mirror Touchscreen (with FaceID) Tutorial](https://smartbuilds.io/smart-mirror-touchscreen-raspberry-pi-4/)
- [[3] Github: Smart-Mirror-with-Real-Time-Face-Detection](https://github.com/ELDERGARLIC/Smart-Mirror-with-Real-Time-Face-Detectio-and-Recognition)
