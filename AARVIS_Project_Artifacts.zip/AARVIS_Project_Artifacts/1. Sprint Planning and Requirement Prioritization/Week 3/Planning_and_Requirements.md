# Sprint 3 Planning: Natural AI Communication

## Goals for Sprint 3

- Define requirements for Natural AI Communication.
- Brainstorming factors based on smart mirror requirements.

### Tasks:
- [ ] Develop Multi-Turn Voice Interaction
- [ ] Integrate Local LLM for Privacy
- [ ] Test Natural Language Processing
- [ ] Refine Conversational Context

### References & Resources:
- [[1] Ollama documentation for running local LLMs on Raspberry Pi](https://dev.to/thegeoffstevens/building-a-completely-offline-voice-assistant-using-a-raspberry-pi-a-local-llm-and-websockets-1ibf)
- [[2] Vosk & faster-whisper open-source STT for local setups](https://github.com/maxolasersquad/max-headbox)
- [[3] Piper Text-to-Speech (TTS) engine for offline voice](https://dev.to/thegeoffstevens/building-a-completely-offline-voice-assistant-using-a-raspberry-pi-a-local-llm-and-websockets-1ibf)
