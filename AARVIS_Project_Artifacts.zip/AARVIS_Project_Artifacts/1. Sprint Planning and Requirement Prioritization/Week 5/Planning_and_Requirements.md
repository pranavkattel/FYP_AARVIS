# Sprint 5 Planning: Voice-Controlled Scheduling

## Goals for Sprint 5

- Define requirements for Voice-Controlled Scheduling.
- Brainstorming factors based on smart mirror requirements.

### Tasks:
- [ ] Integrate Calendar API
- [ ] Develop NLP for Scheduling Commands
- [ ] Test Voice-Based Event Management
- [ ] User Feedback on Scheduling Accuracy

### References & Resources:
- [[1] Google Assistant / AIY Voice Kit integration](https://hackster.io/the-wakh-s/smart-mirror-touchscreen-with-face-recognition-a3e3b5)
- [[2] Google Calendar API OAuth2 guide](https://developers.google.com/calendar/api/guides/auth)
- [[3] Automated scheduling workflows utilizing Microsoft Graph API](https://moldstud.com/articles/p-how-to-build-a-smart-mirror-using-raspberry-pi)
