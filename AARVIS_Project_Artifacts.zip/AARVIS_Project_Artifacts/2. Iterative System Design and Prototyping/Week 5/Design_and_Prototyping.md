# Sprint 5 Design: Voice-Controlled Scheduling

## Design Specifications for Sprint 5

Focusing on: Voice-Controlled Scheduling.

### Prototyping Tasks:
1. Design architecture for **Integrate Calendar API**
1. Design architecture for **Develop NLP for Scheduling Commands**
1. Design architecture for **Test Voice-Based Event Management**
1. Design architecture for **User Feedback on Scheduling Accuracy**

### References & Resources:
- [[1] Google Assistant / AIY Voice Kit integration](https://hackster.io/the-wakh-s/smart-mirror-touchscreen-with-face-recognition-a3e3b5)
- [[2] Google Calendar API OAuth2 guide](https://developers.google.com/calendar/api/guides/auth)
- [[3] Automated scheduling workflows utilizing Microsoft Graph API](https://moldstud.com/articles/p-how-to-build-a-smart-mirror-using-raspberry-pi)
