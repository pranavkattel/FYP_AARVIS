# Sprint 1 Design: Facial Recognition Authentication

## Design Specifications for Sprint 1

Focusing on: Facial Recognition Authentication.

### Prototyping Tasks:
1. Design architecture for **Develop Multi-User Face Recognition**
1. Design architecture for **Integrate Face Auth with Camera**
1. Design architecture for **Test User Differentiation**
1. Design architecture for **Implement Privacy Controls**

### References & Resources:
- [[1] MagicMirror² OpenCV Tutorials - Integration of Face Recognition](https://github.com/EbenKouao/Smart-Mirror-Touchscreen)
- [[2] SmartBuilds.io: Smart Mirror Touchscreen (with FaceID) Tutorial](https://smartbuilds.io/smart-mirror-touchscreen-raspberry-pi-4/)
- [[3] Github: Smart-Mirror-with-Real-Time-Face-Detection](https://github.com/ELDERGARLIC/Smart-Mirror-with-Real-Time-Face-Detectio-and-Recognition)
