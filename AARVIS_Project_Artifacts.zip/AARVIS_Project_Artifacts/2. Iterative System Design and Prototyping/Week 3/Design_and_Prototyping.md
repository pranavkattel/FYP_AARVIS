# Sprint 3 Design: Natural AI Communication

## Design Specifications for Sprint 3

Focusing on: Natural AI Communication.

### Prototyping Tasks:
1. Design architecture for **Develop Multi-Turn Voice Interaction**
1. Design architecture for **Integrate Local LLM for Privacy**
1. Design architecture for **Test Natural Language Processing**
1. Design architecture for **Refine Conversational Context**

### References & Resources:
- [[1] Ollama documentation for running local LLMs on Raspberry Pi](https://dev.to/thegeoffstevens/building-a-completely-offline-voice-assistant-using-a-raspberry-pi-a-local-llm-and-websockets-1ibf)
- [[2] Vosk & faster-whisper open-source STT for local setups](https://github.com/maxolasersquad/max-headbox)
- [[3] Piper Text-to-Speech (TTS) engine for offline voice](https://dev.to/thegeoffstevens/building-a-completely-offline-voice-assistant-using-a-raspberry-pi-a-local-llm-and-websockets-1ibf)
