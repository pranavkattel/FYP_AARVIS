# Sprint 2 Design: Morning Briefings & News

## Design Specifications for Sprint 2

Focusing on: Morning Briefings & News.

### Prototyping Tasks:
1. Design architecture for **Integrate Calendar/Email/Weather APIs**
1. Design architecture for **Develop Personalized Briefing Logic**
1. Design architecture for **Integrate Business News Feeds**
1. Design architecture for **Test Auto Delivery on Face Recognition**

### References & Resources:
- [[1] OpenWeatherMap API setup for smart mirror widgets](https://maker.pro/raspberry-pi/projects/how-to-build-a-raspberry-pi-smart-mirror)
- [[2] Google Calendar iCal integration guidelines](https://howtogeek.com/423166/how-to-build-a-smart-mirror-with-a-raspberry-pi/)
- [[3] MagicMirror² Newsfeed integration](https://github.com/MichMich/MagicMirror/tree/master/modules/default/newsfeed)
