# Sprint 4 Design: Hardware Setup

## Design Specifications for Sprint 4

Focusing on: Hardware Setup.

### Prototyping Tasks:
1. Design architecture for **Set up Raspberry Pi**
1. Design architecture for **Mount monitor and camera**
1. Design architecture for **Test basic connections**
1. Design architecture for **Ensure network connectivity**

### References & Resources:
- [[1] Raspberry Pi 4/5 hardware specifications](https://raspberrypi.com/news/how-to-build-a-super-slim-smart-mirror/)
- [[2] Instructables: Building a wooden frame for a two-way mirror](https://instructables.com/id/How-to-Make-a-Smart-Mirror-1/)
- [[3] VESA mounting techniques](https://all3dp.com/2/raspberry-pi-smart-mirror-best-projects/)
