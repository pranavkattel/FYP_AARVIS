# Sprint 2 Review: Morning Briefings & News

## Retrospective for Sprint 2

Reviewing: Morning Briefings & News.

### Accomplishments:
- Successfully completed: Integrate Calendar/Email/Weather APIs
- Successfully completed: Develop Personalized Briefing Logic
- Successfully completed: Integrate Business News Feeds
- Successfully completed: Test Auto Delivery on Face Recognition

### Areas for Improvement:
- Need to optimize processing time for some tasks.
### References & Resources:
- [[1] OpenWeatherMap API setup for smart mirror widgets](https://maker.pro/raspberry-pi/projects/how-to-build-a-raspberry-pi-smart-mirror)
- [[2] Google Calendar iCal integration guidelines](https://howtogeek.com/423166/how-to-build-a-smart-mirror-with-a-raspberry-pi/)
- [[3] MagicMirror² Newsfeed integration](https://github.com/MichMich/MagicMirror/tree/master/modules/default/newsfeed)
