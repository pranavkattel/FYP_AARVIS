# Sprint 1 Review: Facial Recognition Authentication

## Retrospective for Sprint 1

Reviewing: Facial Recognition Authentication.

### Accomplishments:
- Successfully completed: Develop Multi-User Face Recognition
- Successfully completed: Integrate Face Auth with Camera
- Successfully completed: Test User Differentiation
- Successfully completed: Implement Privacy Controls

### Areas for Improvement:
- Need to optimize processing time for some tasks.
### References & Resources:
- [[1] MagicMirror² OpenCV Tutorials - Integration of Face Recognition](https://github.com/EbenKouao/Smart-Mirror-Touchscreen)
- [[2] SmartBuilds.io: Smart Mirror Touchscreen (with FaceID) Tutorial](https://smartbuilds.io/smart-mirror-touchscreen-raspberry-pi-4/)
- [[3] Github: Smart-Mirror-with-Real-Time-Face-Detection](https://github.com/ELDERGARLIC/Smart-Mirror-with-Real-Time-Face-Detectio-and-Recognition)
