# Sprint 5 Review: Voice-Controlled Scheduling

## Retrospective for Sprint 5

Reviewing: Voice-Controlled Scheduling.

### Accomplishments:
- Successfully completed: Integrate Calendar API
- Successfully completed: Develop NLP for Scheduling Commands
- Successfully completed: Test Voice-Based Event Management
- Successfully completed: User Feedback on Scheduling Accuracy

### Areas for Improvement:
- Need to optimize processing time for some tasks.
### References & Resources:
- [[1] Google Assistant / AIY Voice Kit integration](https://hackster.io/the-wakh-s/smart-mirror-touchscreen-with-face-recognition-a3e3b5)
- [[2] Google Calendar API OAuth2 guide](https://developers.google.com/calendar/api/guides/auth)
- [[3] Automated scheduling workflows utilizing Microsoft Graph API](https://moldstud.com/articles/p-how-to-build-a-smart-mirror-using-raspberry-pi)
