# Sprint 4 Review: Hardware Setup

## Retrospective for Sprint 4

Reviewing: Hardware Setup.

### Accomplishments:
- Successfully completed: Set up Raspberry Pi
- Successfully completed: Mount monitor and camera
- Successfully completed: Test basic connections
- Successfully completed: Ensure network connectivity

### Areas for Improvement:
- Need to optimize processing time for some tasks.
### References & Resources:
- [[1] Raspberry Pi 4/5 hardware specifications](https://raspberrypi.com/news/how-to-build-a-super-slim-smart-mirror/)
- [[2] Instructables: Building a wooden frame for a two-way mirror](https://instructables.com/id/How-to-Make-a-Smart-Mirror-1/)
- [[3] VESA mounting techniques](https://all3dp.com/2/raspberry-pi-smart-mirror-best-projects/)
