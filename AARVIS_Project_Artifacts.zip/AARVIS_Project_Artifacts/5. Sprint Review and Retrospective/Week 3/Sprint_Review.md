# Sprint 3 Review: Natural AI Communication

## Retrospective for Sprint 3

Reviewing: Natural AI Communication.

### Accomplishments:
- Successfully completed: Develop Multi-Turn Voice Interaction
- Successfully completed: Integrate Local LLM for Privacy
- Successfully completed: Test Natural Language Processing
- Successfully completed: Refine Conversational Context

### Areas for Improvement:
- Need to optimize processing time for some tasks.
### References & Resources:
- [[1] Ollama documentation for running local LLMs on Raspberry Pi](https://dev.to/thegeoffstevens/building-a-completely-offline-voice-assistant-using-a-raspberry-pi-a-local-llm-and-websockets-1ibf)
- [[2] Vosk & faster-whisper open-source STT for local setups](https://github.com/maxolasersquad/max-headbox)
- [[3] Piper Text-to-Speech (TTS) engine for offline voice](https://dev.to/thegeoffstevens/building-a-completely-offline-voice-assistant-using-a-raspberry-pi-a-local-llm-and-websockets-1ibf)
